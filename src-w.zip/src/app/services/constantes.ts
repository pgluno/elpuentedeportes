export class Constantes {

  // public static apiUrl : string = 'https://jsonplaceholder.typicode.com/';
  // public static apiUrl : string = 'https://ubi-serv.com/ubiserv-sistema-app/webservice/proveedor/300';
  // public static apiUrl : string = 'http://localhost/prueba';
  public static apiUrl : string = 'https://elpuentedeportes.mx/sistema/public/api';
  // public static apiUrl : string = 'http://localhost/ocicat-sistema/public/api';

}
